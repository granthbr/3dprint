Wall Mount Basket by thescreensavers on Thingiverse: https://www.thingiverse.com/thing:7209176

Summary:
11-5/8 x 3" Outside dims. Uses two #6 screws. 