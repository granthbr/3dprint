Coat Hook by dsmith1960 on Thingiverse: https://www.thingiverse.com/thing:34740

Summary:
This coat hook will fit new-style cubical walls that are approximately 3" wide with a 1/4" top plate.