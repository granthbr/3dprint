Coat hook by capitaenz on Thingiverse: https://www.thingiverse.com/thing:18723

Summary:
Clothes hangers for the balcony or the terrace.